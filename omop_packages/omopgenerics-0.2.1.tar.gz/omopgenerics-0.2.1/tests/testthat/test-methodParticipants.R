test_that("participants no class", {
  x <- 1
  expect_error(participants(x))
})
