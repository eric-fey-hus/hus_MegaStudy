

findUnmappedCodes <- function(){

# search non-standard codes

# see if any have been mapped to 0


}
